#include "Airport.h"
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include "Functions.h"
#include "generalStrings.h"
#define MAX_STR_LEN 255

int isSameAirport(void* ap1, void* ap2)
{
    Airport* airport1 = (Airport*) ap1;
    Airport* airport2 = (Airport*) ap2;
    if(!strcmp(airport1->code, airport2->code))
        return 1;
    return 0;
}
int isAirportCode(Airport* ap, char* IATA)
{
    if (!strcmp(ap->code, IATA))
        return 1;
    return 0;
}



void getAirportName(Airport* pAp)
{
    char* apName = getStrExactLength("Enter airport name");
    trimWhiteSpace(apName);
    capitalizeFirstLetters(apName);
    int wordCount = countWords(apName);
    manipulateAirportName(apName, wordCount);
    pAp->name = apName;
}

void  getAirportCountry(Airport* pAp)
{
    pAp->country = getStrExactLength("Enter airport country:");

}

void getAirportCode(char* code)
{
    int validLength = 1;
    int validLetters = 1;
    char temp[MAX_STR_LEN] = {0};
    do{
    printf("Enter airport code  - 3 UPPER CASE letters\n");
    myGets(temp, MAX_STR_LEN);
    validLength = 1;
    validLetters = 1;
    if (strlen(temp) != 3) {
        printf("code should be 3 letters\n");
        validLength = 0;
        continue;
    }
    for (int i = 0 ; i < IATA_LEN ; i++)
    {
        if (!isalpha(temp[i]) || temp[i] != toupper(temp[i]))
        {
            printf("Need to be upper case letter\n");
            validLetters = 0;
            break;
        }

    }
    } while(validLetters == 0 || validLength == 0);
    for (int i = 0 ; i <= IATA_LEN ; i++)
        code[i] = temp[i];
}
void initAirport(Airport* pAp)
{
    getAirportName(pAp);
    getAirportCountry(pAp);
    getAirportCode(pAp->code);

}

void initAirportNoCode(Airport* pAp) //only for the caseine
{

    getAirportName(pAp);
    getAirportCountry(pAp);

}

int initAirportArr(Airport** apArr, int size)
{
    for (int i = 0 ; i < size; i++)
    {
        apArr[i] =(Airport*) malloc(sizeof(Airport));
        if(!apArr[i])
            return 0;
        initAirport(apArr[i]);
    }
    return 1;
}

void freeAirport(Airport* apArr)
{
    free(apArr->name);
    free(apArr->country);

}

void freeAirportArr(Airport** apArr, int size)
{
    for(int i = 0 ; i < size; i++) {
        free(apArr[i]->name);
        free(apArr[i]->country);
        free(apArr[i]->code);
        free(apArr[i]);
    }
}
void printAirport(const Airport* pAp)
{
    printf("Airport name:%s                  Country: %s                  Code:%s\n", pAp->name, pAp->country, pAp->code);
}
void printAirportArr(const Airport** apArr, int size)
{
    for(int i = 0 ; i < size ; i++)
        printAirport(apArr[i]);
}