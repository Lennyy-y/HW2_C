#include "Functions.h"
#include <ctype.h>
#include <string.h>
#include <stdlib.h>


void trimWhiteSpace(char* str)
{
    size_t len = 0;
    char *leftPointer = str;
    char *rightPointer = NULL;

    len = strlen(str);
    rightPointer = str + len;

    while( isspace((unsigned char) *leftPointer) ) // remove the left whitespace
    {
        ++leftPointer;
    }
    if(rightPointer != leftPointer )
    {
        rightPointer--; // skip the null terminate byte ('/0')
        while(isspace((unsigned char) *(rightPointer)) && rightPointer != leftPointer ) // remove the right whitespace
        {
            rightPointer--;
        }
    }

    if(leftPointer != str && rightPointer == leftPointer ) //if everything is a whitespace then the null terminate will be at the first address
        *str = '\0';
    else if( str + len - 1 != rightPointer ) //move the null terminate to the end of the trimmed string
        *(rightPointer + 1) = '\0';

    rightPointer = str; // moving the string to the address of str so that we can still free the memory with the same pointer
    if(leftPointer != str )
    {
        while( *leftPointer )
        {
            *rightPointer++ = *leftPointer++;
        }
        *rightPointer = '\0';
    }
}


void capitalizeFirstLetters(char* str)
{
    for (int i = 0 ; i < strlen(str) ; i++)
    {
        if (i == 0)
        {
            if(*(str + i) >= 'a' && *(str + i) <= 'z')
                *(str + i) -= 32; // subtract 32 to get the uppercase letter
        }
        if (isspace(*(str + i)) && isalpha(*(str + i + 1))) {
            i++;
            if(*(str + i) >= 'a' && *(str + i) <= 'z')
                *(str + i) -= 32; // subtract 32 to get the uppercase letter
        }
    }
}

int countWords(char* str)
{
    int wordCount = 0;
    int length = (int) strlen(str);
    int readingWord = 0;
    for (int i = 0 ; i < length ; i++)
    {
        if (!readingWord && isalpha(str[i])) {
            readingWord = 1;
            wordCount++;
        }
        if(readingWord && isspace(str[i]))
            readingWord = 0;
    }
    return wordCount;
}

int countSpaces(char* str)
{
    int spaceCount = 0;
    int length = strlen(str);
    for (int i = 0 ; i < length ; i++)
    {
        if(isspace(str[i]))
            spaceCount++;
    }
    return spaceCount;
}

void manipulateAirportName(char* str, int wordCount)
{

    int length = strlen(str);
    char* endPointer = str + length;

    if(wordCount == 1) //if the string is only one word
    {
        for(int i = 0 ; i < strlen(str) ; i++)
        {
            if(*(str + i) >= 'a' && *(str + i) <= 'z')
                *(str+i) -= 32;

        }
        for(int i = 1 ; (*(str + i) != '\0' || *(str + i + 1) != '\0') ; i+=2) // stopping condition depends on whether the string length is even or odd
        {
            length = (int)(endPointer - str);
            memmove(str + i + 1, str + i, length - i + 1);
            endPointer++;
            *(str + i) = '_';
        }
    }

    else if (wordCount % 2 == 0) { // if there is an even number of words
        int spaceCount = countSpaces(str);
        char* pStr = str;
        char* tempStr = (char*)calloc(length + length - 2, sizeof(char));
        char* pTemp = tempStr;
        int readingWord = 0;
        for (int i = 0 ; i < length ; i++)
        {
            if(!readingWord && isalpha(str[i]))
            {
                readingWord = 1;
                pStr = str + i;
            }
            else if(readingWord && isspace(str[i]))
            {
                memmove(pTemp, pStr, str + i - pStr);
                pTemp = pTemp + (str + i - pStr);
                if(i + 1 < length) {
                    strcat (pTemp, "  ");
                    pTemp += 2;
                }
                readingWord = 0;
            }
        }
        memmove(pTemp, pStr, str + length - pStr + 2);
        pTemp = pTemp + (str + length - pStr + 2);
        *(pTemp) = '\0';
        if(strlen(tempStr) < strlen(str))
            memmove((char*)str, (char*)tempStr, strlen(str));
        else
            memmove((char*)str, (char*)tempStr, strlen(tempStr));
        free(tempStr);
    }
}