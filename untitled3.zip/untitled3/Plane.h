#pragma once
// #ifndef PLANE_
// #define PLANE_


typedef enum {
    Travelers, Luggage, Military, NumOfEnum
    }planeType;

static const char* planeTypes[NumOfEnum] = {"Commercial","Cargo","Military"};

typedef struct
{
    planeType type;
    int serialNum;

}Plane;


void initPlane(Plane* pPl,Plane* pArr,int planeCount);
int isValidPlane(Plane* p);
void getPlaneSerialNum(Plane* pPl, Plane* pArr, int planeCount);
int initPlaneArr(Plane** plArr, int size);
planeType getPlaneType();
void printPlane(const Plane* pPl);
void printPlanesArr(const Plane* plArr, int size);
void freePlaneArr(Plane** plArr, int size);

// #endif