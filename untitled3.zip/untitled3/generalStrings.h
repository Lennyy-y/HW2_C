#pragma once
// #ifndef GENERALSTRINGS_
// #define GENERALSTRINGS_

#define MAX_LENGTH 255

char*	getStrExactLength(const char* msg);
char* 	myGets(char* buf, int size);

// #endif