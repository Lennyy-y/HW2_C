#include "Airline.h"
#include <stdio.h>
#include <stdlib.h>
#include "generalStrings.h"

int addFlight(Airline* arl, Flight* fl)
{
    if (!isValidPlane(&(fl->plane)) || !strlen(fl->arrivalCode) || !strlen(fl->departureCode) || !isValidDate(&(fl->flightDate)))
        return 0;
    arl->allFlights = (Flight**) realloc(arl->allFlights,(arl->flightCount+1)*sizeof(Flight*));
    if(!arl->allFlights)
        return 0;
    *arl->allFlights[arl->flightCount] = *fl;
    arl->flightCount++;
    return 1;
}
int addPlane(Airline* arl)
{
    if(arl->planeCount == 0) {
        arl->planeArr = (Plane *) malloc((arl->planeCount + 1)*sizeof(Plane));
        if(!arl->planeArr)
            return 0;
    }
    else {
        arl->planeArr = (Plane *) realloc(arl, (arl->planeCount + 1) * sizeof(Plane));
        if (!arl->planeArr)
            return 0;
    }
    initPlane(&arl->planeArr[arl->planeCount++], arl->planeArr, arl->planeCount);
    return 1;
}
void doPrintFlightsWithPlaneType(Airline* arl, planeType planeT)
{
    for (int i = 0 ; i < arl->flightCount ; i++)
    {
        if (isPlaneTypeInFlight(arl->allFlights[i], planeT))
            printFlight(arl->allFlights[i]);
    }
}
void initAirline(Airline* pAl)
{
    pAl->name = getStrExactLength("Enter the airline name");
    pAl->flightCount = 0;
    pAl->planeCount = 0;
}
void printAirline(const Airline* pAl)
{
        printf("Airline name %s has %d planes and %d flights.\n", pAl->name, pAl->planeCount, pAl->flightCount);
        printf("List of planes:\n");
        printPlanesArr((const Plane *) pAl->planeArr, pAl->planeCount);
        printf("\nFlights:\n");
        printFlightArr((const Flight **) pAl->allFlights, pAl->flightCount);
}

void freeCompany(Airline* pAl)
{
        freeFlightArr(pAl->allFlights,pAl->flightCount);
        free(pAl->planeArr);
        free(pAl->name);
}

