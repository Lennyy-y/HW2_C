#pragma once
// #ifndef FUNCTIONS_
// #define FUNCTIONS_

void trimWhiteSpace(char* str);
void capitalizeFirstLetters(char* str);
void manipulateAirportName(char* str, int wordCount);
int countWords(char* str);
int countSpaces(char* str);

// #endif