#pragma once
// #ifndef DATE_
// #define DATE_

typedef struct
{
    int day;
    int month;
    int year;
}Date;
int isValidDate(Date* d);
void initDate(Date* pD);
void getCorrectDate(Date* pD);
void printDate(const Date* pD);

// #endif