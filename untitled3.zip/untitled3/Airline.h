#pragma once
// #ifndef AIRLINE_
// #define AIRLINE_

#include "Flight.h"
#include "Plane.h"
typedef struct
{
    char* name;
    int flightCount;
    int planeCount;
    Plane* planeArr;
    Flight** allFlights;
}Airline;

int addFlight(Airline* arl, Flight* fl);
int addPlane(Airline* arl);
void doPrintFlightsWithPlaneType(Airline* arl, planeType planeT);
void initAirline(Airline* pAl);
void printAirline(const Airline* pAl);
void freeCompany(Airline* pAl);

// #endif