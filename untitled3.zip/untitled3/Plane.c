#include "Plane.h"
#include <stdio.h>
#include <stdlib.h>

int isValidPlane(Plane* p)
{
    if (!p->type || !p->serialNum)
        return 0;
    return 1;
}

void initPlane(Plane* pPl,Plane* pArr,int planeCount)
{
    getPlaneSerialNum(pPl, pArr, planeCount) ;
    pPl->type = getPlaneType();
}
//int initPlaneArr(Plane** plArr, int size)
//{
//  for (int i = 0 ; i < size ; i++)
//   {
//         plArr[i] = malloc(sizeof(Plane));
//         if(!plArr[i])
//             return 0;
//         initPlane(plArr[i],plArr,size);
//     }
 //    return 1;
// }
planeType getPlaneType()
{
    int type;
    do {
        printf("Please enter one of the following types\n");
        for (int i = 0; i < NumOfEnum; i++)
            printf("%d for %s\n", i, planeTypes[i]);
        printf("\n");
        scanf("%d", &type);
    } while (type < 0 || type >= NumOfEnum);
    return (planeType)type;
}

void getPlaneSerialNum(Plane* pPl, Plane* pArr, int planeCount)
{
    int valid = 1;
    int temp = 0;
    do
    {
        valid = 1;
        printf("Enter plane serial number - between 1 to 9999\n");
        scanf("%d", &temp);
        if(temp < 1 || temp > 9999) {
            valid = 0;
            continue;
        }
        if(planeCount == 0)
            break;
        for ( int i = 0; i < planeCount; i++)
        {
            if ( pPl->serialNum == pArr[i].serialNum )
            {
                valid = 0;
            }
        }

    } while(valid == 0);
    pPl->serialNum = temp;

}

void printPlane(const Plane* pPl)
{
    printf("Plane: serial number:%d, type %s", pPl->serialNum, planeTypes[pPl->type]);
}
void printPlanesArr(const Plane* plArr, int size)
{
    for (int i = 0 ; i < size ; i++)
        printPlane(&plArr[i]);
}

void freePlaneArr(Plane** plArr, int size)
{
    for(int i = 0 ; i < size ; i++)
    {
        free(plArr[i]);
    }
}