#include "Airport.h"
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include "string.h"
#include "Functions.h"
#include "generalStrings.h"
#define MAX_STR_LEN 255

int isSameAirport(void* ap1, void* ap2)
{
    Airport* airport1 = (Airport*) ap1;
    Airport* airport2 = (Airport*) ap2;
    if(!strcmp(airport1->code, airport2->code))
        return 1;
    return 0;
}
int isAirportCode(Airport* ap, char* IATA)
{
    if (!strcmp(ap->code, IATA))
        return 1;
    return 0;
}
char*  getAirportName()
{
    char* apName = (char*) malloc(MAX_STR_LEN);
    printf("Enter airport name:\n");
    myGets(apName, MAX_STR_LEN);
    trimWhiteSpace(apName);
    numOfWords(apName);
    capitalizeFirstLetters(apName);
    return apName;
}

void  getAirportCountry(Airport* pAp)
{

    printf("Enter airport country:\n");
    myGets(pAp->country, MAX_STR_LEN);

}

void getAirportCode(char* code)
{
    int wrong=1;
    while(1)
    {
        printf("Enter IATA in upper case (Max length %d)\n", IATA_LEN);
        myGets(code, IATA_LEN + 1);
        if( strlen(code) > IATA_LEN )
        {
            printf("This IATA is more than 3 digits");
            continue;
        }
        for ( int i = 0; i < 3; i++)
        {
            if( code[i] != toupper(code[i]))
            {
                printf("This IATA is not in capital letters");
                wrong=0;
                i=3;
            }
        }
        if( wrong == 0)
            continue;
        else
            break;
    }
}
void initAirport(Airport* pAp)
{
    pAp->name = getAirportName();
    getAirportCountry(pAp);
    getAirportCode(pAp->code);

}

void initAirportNoCode(Airport* pAp) //only for the caseine
{

    pAp->name =  getAirportName();
    getAirportCountry(pAp);

}

int initAirportArr(Airport** apArr, int size)
{
    for (int i = 0 ; i < size; i++)
    {
        apArr[i] =(Airport*) malloc(sizeof(Airport));
        if(!apArr[i])
            return 0;
        initAirport(apArr[i]);
    }
    return 1;
}

void freeAirport(Airport* apArr)
{
    free(apArr->name);
    free(apArr->country);

}

void freeAirportArr(Airport** apArr, int size)
{
    for(int i = 0 ; i < size; i++) {
        free(apArr[i]->name);
        free(apArr[i]->country);
        free(apArr[i]->code);
        free(apArr[i]);
    }
}
void printAirport(const Airport* pAp)
{
    printf("Airport name: %s\nAirport country: %s\nIATA: %s\n", pAp->name, pAp->country, pAp->code);
}
void printAirportArr(const Airport** apArr, int size)
{
    for(int i = 0 ; i < size ; i++)
        printAirport(apArr[i]);
}