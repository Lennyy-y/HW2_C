#ifndef __FUNCTIONS____
#define __FUNCTIONS____

void trimWhiteSpace(char* str);
void capitalizeFirstLetters(char* str);
void numOfWords(char* str);

#endif