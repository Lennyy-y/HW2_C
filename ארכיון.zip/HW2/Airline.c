#include "Airline.h"
#include <stdio.h>
#include <stdlib.h>
#include "generalStrings.h"

int addFlight(Airline* arl, Flight* fl)
{
    if (!isValidPlane(&(fl->plane)) || !strlen(fl->arrivalCode) || !strlen(fl->departureCode) || !isValidDate(&(fl->flightDate)))
        return -1;
    arl->allFlights = (Flight**) realloc(arl->allFlights,(arl->flightCount+1)*sizeof(Flight*));
    if(!arl->allFlights)
        return 0;
    *arl->allFlights[arl->flightCount] = *fl;
    arl->flightCount++;
}
int addPlane(Airline* arl, Plane* pl)
{
    if(arl->planeCount != 0)
    {
        for ( int i = 0; i < arl->planeCount; i++)
        {
            if(arl->allPlanes[i].serialNum == pl->serialNum)
                return -1;
        }
    }

    arl->allPlanes = (Plane*) realloc(arl->allPlanes,(arl->planeCount+1)* sizeof(Plane));
    if(!arl->allPlanes)
        return 0;
    arl->allPlanes[arl->planeCount] = *pl;
    arl->planeCount++;
    return 1;
}
void doPrintFlightsWithPlaneType(Airline* arl, planeType planeT)
{
    for (int i = 0 ; i < arl->flightCount ; i++)
    {
        if (isPlaneTypeInFlight(arl->allFlights[i], planeT))
            printFlight(arl->allFlights[i]);
    }
}
#define MAX_AIRLINE_FLIGHTS 2
int initAirline(Airline* pAl)
{
    pAl->airlineName = getStrExactLength("Enter the airline name");
    pAl->flightCount = 0;
    pAl->planeCount = 0;
    pAl->allFlights = NULL;
    pAl->allPlanes = NULL;

}
void printAirline(const Airline* pAl)
{
        printf("Airline name %s has %d planes and %d flights.\n", pAl->airlineName, pAl->planeCount, pAl->flightCount);
        printf("List of planes:\n");
        printPlaneArr((const Plane **) pAl->allPlanes, pAl->planeCount);
        printf("\nFlights:\n");
        printFlightArr((const Flight **) pAl->allFlights, pAl->flightCount);
}

void freeAirline(Airline* pAl)
{
        freeFlightArr(pAl->allFlights,pAl->flightCount);
        free(pAl->allPlanes);
        free(pAl->airlineName);
}

