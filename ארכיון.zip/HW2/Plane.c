#include "Plane.h"
#include <stdio.h>
#include <stdlib.h>


int isValidPlane(Plane* p)
{
    if (!p->type || !p->serialNum)
        return 0;
    return 1;
}

void initPlane(Plane* pPl,Plane* pArr,int planeCount)
{
    pPl->type = getPlaneType();
    getPlaneSnum(pPl,pArr,planeCount) ;
}
//int initPlaneArr(Plane** plArr, int size)
//{
//  for (int i = 0 ; i < size ; i++)
//   {
//         plArr[i] = malloc(sizeof(Plane));
//         if(!plArr[i])
//             return 0;
//         initPlane(plArr[i],plArr,size);
//     }
 //    return 1;
// }
planeType getPlaneType()
{
    int type;
    printf("Enter plane type\n");
    do {
        for (int i = 0; i < NumOfEnum; i++)
            printf("Enter %d for %s\n", i, planeTypes[i]);
        scanf("%d", &type);
    } while (type < 0 || type >= NumOfEnum);
    return (planeType)type;
}

void getPlaneSnum(Plane* pPl,Plane* pArr,int planeCount)
{
    while(1)
    {
        printf("Enter the serial number u want for this plane \n");
        scanf("%d", &(pPl->serialNum));
        if( planeCount == 0 )
            break;
        for ( int i = 0; i < planeCount; i++)
        {
            if ( pPl->serialNum == pArr[i].serialNum )
            {
                printf("The serial number u wanted for this plane is not available \n");
                continue;
            }
        }
    break;
    }
}

void printPlane(const Plane* pPl)
{
    printf("Plane type: %s\nSerial number: %d\n", planeTypes[pPl->type], pPl->serialNum);
}
void printPlaneArr(const Plane** plArr, int size)
{
    for (int i = 0 ; i < size ; i++)
        printPlane(plArr[i]);
}

void freePlaneArr(Plane** plArr, int size)
{
    for(int i = 0 ; i < size ; i++)
    {
        free(plArr[i]);
    }
}