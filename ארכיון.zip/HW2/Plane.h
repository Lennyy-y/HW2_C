#ifndef __PLANE____
#define __PLANE____


typedef enum {
    Travelers,Luggage,Military,NumOfEnum
    } planeType;

static const char* planeTypes[NumOfEnum] = {"Travelers,Luggage,Military"};

typedef struct
{
    planeType type;
    int serialNum;

}Plane;


void initPlane(Plane* pPl,Plane* pArr,int planeCount);
int isValidPlane(Plane* p);
void getPlaneSnum(Plane* pPl,Plane* pArr,int planeCount);
int initPlaneArr(Plane** plArr, int size);
planeType getPlaneType();
void printPlane(const Plane* pPl);
void printPlaneArr(const Plane** plArr, int size);
void freePlaneArr(Plane** plArr, int size);

#endif